import groovy.json.JsonOutput
import groovy.json.JsonSlurper

/** JSON store of the OpenCATS desk, kept beside the installed plugin. */
class OpenCatsStore {
    static File root() {
        def override = System.getProperty('opencats.data')
        if (override) {
            def dir = new File(override)
            dir.mkdirs()
            return dir
        }
        def dir = new File(backend.pattern.DataRoot.folder('plugins'), 'opencats')
        dir.mkdirs()
        dir
    }

    static Map load() {
        def file = new File(root(), 'store.json')
        Map data = file.isFile() ? (plain(new JsonSlurper().parse(file, 'UTF-8')) as Map) : OpenCatsModel.blank()
        def fresh = OpenCatsModel.blank()
        fresh.each { key, value ->
            if (data[key] == null) {
                data[key] = value instanceof List ? [] : value
            }
        }
        if (!(data.settings instanceof Map)) {
            data.settings = fresh.settings
        }
        fresh.settings.each { key, value ->
            if (data.settings[key] == null) {
                data.settings[key] = value
            }
        }
        data
    }

    static void write(Map data) {
        def file = new File(root(), 'store.json')
        file.parentFile.mkdirs()
        file.setText(JsonOutput.prettyPrint(JsonOutput.toJson(data)), 'UTF-8')
    }

    static File files() {
        def dir = new File(root(), 'files')
        dir.mkdirs()
        dir
    }

    static String nextId(Map data, String prefix) {
        int current = data.seq?.toString()?.isInteger() ? data.seq.toString().toInteger() : 1
        data.seq = current + 1
        prefix + current
    }

    private static Object plain(value) {
        if (value instanceof Map) {
            def copy = new LinkedHashMap()
            value.each { key, item -> copy[key.toString()] = plain(item) }
            return copy
        }
        if (value instanceof List) {
            return value.collect { plain(it) }
        }
        value
    }
}
