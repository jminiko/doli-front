import backend.dsl.ScreenException
import com.lowagie.text.Document
import com.lowagie.text.Paragraph
import com.lowagie.text.pdf.PdfWriter

import java.time.LocalDate

/** Writes and reads the OpenCATS records. */
class OpenCatsActions {
    static void run(Map data, String verb, Map payload) {
        switch (verb) {
            case 'save': save(data, payload); break
            case 'remove': remove(data, payload); break
            case 'pipeline': pipeline(data, payload); break
            case 'activity': activity(data, payload); break
            case 'attach': attach(data, payload); break
            case 'tags': tags(data, payload); break
            case 'listAdd': listAdd(data, payload); break
            default: throw new ScreenException(404, 'error.notFound')
        }
        data.notice = 'oc.saved'
    }

    static Map careers(Map data, Closure text) {
        boolean open = data.settings?.careers == '1'
        [
            enabled : open,
            siteName: data.settings?.siteName ?: 'OpenCATS',
            closed  : text('oc.closed'),
            title   : text('oc.portalTitle'),
            apply   : text('oc.apply'),
            sent    : text('oc.applied'),
            jobs    : open ? publicJobs(data) : []
        ]
    }

    static void applyCareer(Map data, Map payload) {
        if (data.settings?.careers != '1') {
            throw new ScreenException(404, 'oc.closed')
        }
        def job = row(data, 'jobs', payload.job)
        if (!job || job.isPublic != '1' || job.status != 'Active') {
            throw new ScreenException(404, 'error.notFound')
        }
        def input = new LinkedHashMap(payload ?: [:])
        input.form = 'candidate'
        input.source = input.source ?: 'career'
        input.isActive = '1'
        input.force = '1'
        def email = input.email1?.toString()?.trim()?.toLowerCase()
        def candidate = email ? (data.candidates ?: []).find { it.email1?.toString()?.trim()?.toLowerCase() == email } : null
        if (!candidate) {
            candidate = save(data, input)
        }
        def existing = (data.pipeline ?: []).find { it.candidate == candidate.id && it.job == job.id }
        if (!existing) {
            def today = LocalDate.now().toString()
            data.pipeline << [id: OpenCatsStore.nextId(data, 'p'), candidate: candidate.id, job: job.id, status: 'submitted', rating: '0', added: today, updated: today]
        }
        data.activities << [
            id   : OpenCatsStore.nextId(data, 'a'),
            kind : 'candidates',
            item : candidate.id,
            type : 'note',
            notes: "Candidature portail : ${job.title}",
            date : LocalDate.now().toString(),
            owner: 'career'
        ]
        data.notice = 'oc.applied'
    }

    static Map document(Map data, String nodeId) {
        if (!nodeId) {
            return null
        }
        if (nodeId.startsWith('csv-')) {
            def bucket = nodeId.substring(4)
            if (!(bucket in ['candidates', 'companies', 'contacts', 'jobs'])) {
                return null
            }
            return [bytes: csv(data, bucket).getBytes('UTF-8'), mime: 'text/csv', filename: "${bucket}.csv"]
        }
        if (nodeId.startsWith('pdf-candidate-')) {
            return pdfCandidate(data, nodeId.substring('pdf-candidate-'.length()))
        }
        if (nodeId.startsWith('pdf-job-')) {
            return pdfJob(data, nodeId.substring('pdf-job-'.length()))
        }
        if (nodeId.startsWith('file-')) {
            def file = (data.attachments ?: []).find { it.id == nodeId.substring(5) }
            def stored = file ? new File(OpenCatsStore.files(), file.id.toString()) : null
            if (!stored?.isFile()) {
                return null
            }
            return [bytes: stored.bytes, mime: file.mime ?: 'application/octet-stream', filename: file.name ?: 'file']
        }
        null
    }

    private static Map save(Map data, Map payload) {
        String form = payload.form?.toString()
        if (form == 'settings') {
            return saveSettings(data, payload)
        }
        if (form == 'import') {
            return importCsv(data, payload)
        }
        if (form == 'list') {
            return saveList(data, payload)
        }
        if (form == 'template') {
            return saveTemplate(data, payload)
        }
        if (form == 'tag') {
            return saveTag(data, payload)
        }
        def fields = OpenCatsModel.fields(form)
        def bucket = OpenCatsModel.bucket(form)
        if (!fields || !bucket) {
            throw new ScreenException(422, 'oc.required')
        }
        Map current = payload.row ? row(data, bucket, payload.row) : null
        if (payload.row && !current) {
            throw new ScreenException(404, 'error.notFound')
        }
        boolean creating = current == null
        def record = current ?: [id: OpenCatsStore.nextId(data, prefix(form))]
        assign(record, payload, fields)
        check(record, fields)
        if (form == 'candidate') {
            duplicate(data, record, payload)
        }
        if (form == 'job') {
            record.type = record.type ?: 'H'
            record.status = record.status ?: 'Active'
        }
        if (form == 'event' && !(record.date ==~ /\d{4}-\d{2}-\d{2}/)) {
            throw new ScreenException(422, 'oc.required')
        }
        if (record.companyId && !row(data, 'companies', record.companyId)) {
            throw new ScreenException(422, 'oc.required')
        }
        if (record.contactId && !row(data, 'contacts', record.contactId)) {
            throw new ScreenException(422, 'oc.required')
        }
        if (creating) {
            record.created = LocalDate.now().toString()
            record.owner = payload.actorLogin?.toString() ?: ''
            data[bucket] << record
        }
        record.updated = LocalDate.now().toString()
        payload.row = record.id
        if (form == 'event') {
            payload.section = 'calendar'
        }
        record
    }

    private static void remove(Map data, Map payload) {
        String form = payload.form?.toString()
        String bucket = OpenCatsModel.bucket(form)
        def record = bucket ? row(data, bucket, payload.row) : null
        if (!record) {
            throw new ScreenException(404, 'error.notFound')
        }
        if (form == 'company') {
            boolean used = (data.contacts ?: []).any { it.companyId == record.id } || (data.jobs ?: []).any { it.companyId == record.id }
            if (used) {
                throw new ScreenException(409, 'oc.linked')
            }
        }
        data[bucket].removeAll { it.id == record.id }
        if (form == 'candidate') {
            data.pipeline?.removeAll { it.candidate == record.id }
        }
        if (form == 'job') {
            data.pipeline?.removeAll { it.job == record.id }
        }
        if (form == 'contact') {
            data.jobs?.each { if (it.contactId == record.id) it.contactId = '' }
        }
        if (form == 'tag') {
            data.values().each { value ->
                if (value instanceof List) {
                    value.each { item ->
                        if (item instanceof Map && item.tags instanceof List) {
                            item.tags.removeAll { it == record.id }
                        }
                    }
                }
            }
        }
        String kind = OpenCatsModel.bucket(form)
        data.activities?.removeAll { it.kind == kind && it.item == record.id }
        data.attachments?.findAll { it.kind == kind && it.item == record.id }?.each { file ->
            new File(OpenCatsStore.files(), file.id.toString()).delete()
        }
        data.attachments?.removeAll { it.kind == kind && it.item == record.id }
        data.lists?.each { list -> list.items?.removeAll { it == record.id } }
        payload.row = ''
    }

    private static void pipeline(Map data, Map payload) {
        def candidate = row(data, 'candidates', payload.candidate)
        def job = row(data, 'jobs', payload.job)
        if (!candidate || !job) {
            throw new ScreenException(422, 'oc.required')
        }
        def status = payload.status?.toString() ?: 'noContact'
        if (!OpenCatsModel.PIPELINE.any { it.id == status }) {
            throw new ScreenException(422, 'oc.required')
        }
        def rating = payload.rating?.toString() ?: '0'
        if (!(rating ==~ /[0-5]/)) {
            rating = '0'
        }
        def today = LocalDate.now().toString()
        def link = (data.pipeline ?: []).find { it.candidate == candidate.id && it.job == job.id }
        if (!link) {
            link = [id: OpenCatsStore.nextId(data, 'p'), candidate: candidate.id, job: job.id, added: today]
            data.pipeline << link
        }
        link.status = status
        link.rating = rating
        link.updated = today
        payload.section = payload.section ?: 'jobs'
        payload.row = payload.back == 'candidate' ? candidate.id : job.id
    }

    private static void activity(Map data, Map payload) {
        String kind = payload.kind?.toString()
        def record = row(data, kind, payload.item)
        if (!record) {
            throw new ScreenException(422, 'oc.required')
        }
        def type = payload.type?.toString() ?: 'note'
        if (!OpenCatsModel.ACTIVITIES.any { it.id == type }) {
            throw new ScreenException(422, 'oc.required')
        }
        def notes = fill(data, payload.notes?.toString() ?: '', kind, record.id, payload.template?.toString())
        if (!notes.trim()) {
            throw new ScreenException(422, 'oc.required')
        }
        data.activities << [
            id   : OpenCatsStore.nextId(data, 'a'),
            kind : kind,
            item : record.id,
            type : type,
            notes: clip(notes, 8000),
            date : payload.date?.toString() ?: LocalDate.now().toString(),
            owner: payload.actorLogin?.toString() ?: ''
        ]
        payload.row = record.id
    }

    private static void attach(Map data, Map payload) {
        def upload = payload.upload
        def record = row(data, payload.kind?.toString(), payload.item)
        if (!record || !upload || upload.empty) {
            throw new ScreenException(422, 'oc.required')
        }
        if ((upload.size as long) > 20_000_000) {
            throw new ScreenException(422, 'error.uploadTooLarge')
        }
        def id = OpenCatsStore.nextId(data, 'f')
        def safe = (upload.originalFilename ?: 'file').toString().replaceAll('[^A-Za-z0-9._-]', '_')
        if (!safe || safe == '.' || safe == '..') {
            safe = 'file'
        }
        new File(OpenCatsStore.files(), id).bytes = upload.bytes
        data.attachments << [
            id  : id,
            kind: payload.kind.toString(),
            item: record.id,
            name: clip(safe, 180),
            mime: upload.contentType ?: 'application/octet-stream',
            size: upload.size as long
        ]
        payload.row = record.id
    }

    private static void tags(Map data, Map payload) {
        def record = row(data, payload.kind?.toString(), payload.item)
        if (!record) {
            throw new ScreenException(404, 'error.notFound')
        }
        def raw = payload.tags
        if (payload.metaClass.respondsTo(payload, 'list', String)) {
            def listed = payload.list('tags')
            if (listed) {
                raw = listed
            }
        }
        List ids = []
        if (raw instanceof Collection) {
            ids.addAll(raw.collect { it?.toString() })
        } else if (raw) {
            ids << raw.toString()
        }
        def known = (data.tags ?: []).collect { it.id.toString() } as Set
        record.tags = ids.findAll { it in known }.unique()
        payload.row = record.id
    }

    private static void listAdd(Map data, Map payload) {
        def list = row(data, 'lists', payload.list)
        def record = list ? row(data, list.kind?.toString(), payload.item) : null
        if (!list || !record) {
            throw new ScreenException(422, 'oc.required')
        }
        if (!(list.items instanceof List)) {
            list.items = []
        }
        if (!(record.id in list.items)) {
            list.items << record.id
        }
        payload.section = 'lists'
        payload.row = list.id
    }

    private static Map saveSettings(Map data, Map payload) {
        data.settings.siteName = clip(payload.siteName?.toString() ?: 'OpenCATS', 120) ?: 'OpenCATS'
        data.settings.careers = truth(payload.careers) ? '1' : '0'
        data.settings.country = clip(payload.country?.toString() ?: '', 80)
        data.settings.city = clip(payload.city?.toString() ?: '', 120)
        payload.section = 'settings'
        payload.row = ''
        data.settings
    }

    private static Map importCsv(Map data, Map payload) {
        def lines = payload.csv?.toString()?.split(/\r?\n/)?.findAll { it?.trim() } ?: []
        if (lines.size() < 2) {
            throw new ScreenException(422, 'oc.required')
        }
        def header = splitCsv(lines[0]).collect { it.trim() }
        int count = 0
        lines.drop(1).each { String line ->
            def cells = splitCsv(line)
            def input = [form: 'candidate', force: '1', isActive: '1', source: 'import']
            header.eachWithIndex { String name, int index ->
                if (name) {
                    input[name] = index < cells.size() ? cells[index] : ''
                }
            }
            if (input.firstName && input.lastName) {
                save(data, input)
                count++
            }
        }
        payload.section = 'import'
        payload.row = ''
        [count: count]
    }

    private static Map saveList(Map data, Map payload) {
        def name = clip(payload.name?.toString()?.trim() ?: '', 160)
        def kind = payload.kind?.toString()
        if (!name || !(kind in ['candidates', 'companies', 'contacts', 'jobs'])) {
            throw new ScreenException(422, 'oc.required')
        }
        Map list = payload.row ? row(data, 'lists', payload.row) : null
        if (!list) {
            list = [id: OpenCatsStore.nextId(data, 'l'), items: []]
            data.lists << list
        }
        if (list.kind && list.kind != kind) {
            list.items = []
        }
        list.name = name
        list.kind = kind
        payload.section = 'lists'
        payload.row = list.id
        list
    }

    private static Map saveTemplate(Map data, Map payload) {
        def title = clip(payload.title?.toString()?.trim() ?: '', 160)
        def body = clip(payload.body?.toString() ?: '', 8000)
        if (!title || !body.trim()) {
            throw new ScreenException(422, 'oc.required')
        }
        Map template = payload.row ? row(data, 'templates', payload.row) : null
        if (!template) {
            template = [id: OpenCatsStore.nextId(data, 'm')]
            data.templates << template
        }
        template.title = title
        template.body = body
        payload.section = 'templates'
        payload.row = template.id
        template
    }

    private static Map saveTag(Map data, Map payload) {
        def name = clip(payload.name?.toString()?.trim() ?: '', 80)
        if (!name) {
            throw new ScreenException(422, 'oc.required')
        }
        Map tag = payload.row ? row(data, 'tags', payload.row) : null
        if (!tag) {
            tag = [id: OpenCatsStore.nextId(data, 't')]
            data.tags << tag
        }
        tag.name = name
        payload.section = 'tags'
        payload.row = tag.id
        tag
    }

    private static void assign(Map record, Map payload, List<Map> fields) {
        fields.each { Map field ->
            String name = field.name
            if (field.type == 'bool') {
                record[name] = truth(payload[name]) ? '1' : '0'
            } else {
                record[name] = clip(payload[name]?.toString()?.trim() ?: '', (field.max ?: 240) as int)
            }
        }
    }

    private static void check(Map record, List<Map> fields) {
        fields.each { Map field ->
            def value = record[field.name]?.toString() ?: ''
            if (field.required && !value) {
                throw new ScreenException(422, 'oc.required')
            }
            if (field.type == 'email' && value && !(value ==~ /[^@\s]+@[^@\s]+\.[^@\s]+/)) {
                throw new ScreenException(422, 'oc.email')
            }
            if (field.type == 'number' && value && !(value ==~ /\d{1,6}/)) {
                throw new ScreenException(422, 'oc.required')
            }
            if (field.type == 'date' && value && !(value ==~ /\d{4}-\d{2}-\d{2}/)) {
                throw new ScreenException(422, 'oc.required')
            }
            if (field.type == 'choice' && value && field.options in ['jobType', 'jobStatus', 'activity', 'gender', 'yesno', 'kinds']) {
                def options = options(field.options)
                if (!options.any { it.id == value }) {
                    throw new ScreenException(422, 'oc.required')
                }
            }
        }
    }

    private static void duplicate(Map data, Map record, Map payload) {
        def email = record.email1?.toString()?.toLowerCase()
        if (!email) {
            return
        }
        boolean clash = (data.candidates ?: []).any { it.id != record.id && it.email1?.toString()?.toLowerCase() == email }
        if (clash && !truth(payload.force)) {
            throw new ScreenException(409, 'oc.duplicate')
        }
    }

    private static List<Map> options(String name) {
        switch (name) {
            case 'jobType': return OpenCatsModel.JOB_TYPES
            case 'jobStatus': return OpenCatsModel.JOB_STATUS
            case 'activity': return OpenCatsModel.ACTIVITIES
            case 'gender': return OpenCatsModel.GENDERS
            case 'yesno': return OpenCatsModel.YESNO
            case 'kinds': return OpenCatsModel.KINDS
            default: return []
        }
    }

    private static String fill(Map data, String notes, String kind, String item, String templateId) {
        def template = templateId ? row(data, 'templates', templateId) : null
        def body = template?.body ?: notes
        def record = row(data, kind, item)
        def job = kind == 'jobs' ? record : null
        def candidate = kind == 'candidates' ? record : null
        body.replace('${name}', OpenCatsModel.person(candidate) ?: OpenCatsModel.caption(data, kind, item))
            .replace('${job}', job?.title ?: '')
            .replace('${date}', LocalDate.now().toString())
    }

    private static List<Map> publicJobs(Map data) {
        (data.jobs ?: []).findAll { it.isPublic == '1' && it.status == 'Active' }.collect { job ->
            [
                id         : job.id,
                title      : job.title,
                city       : job.city,
                type       : job.type,
                company    : OpenCatsModel.caption(data, 'companies', job.companyId),
                description: job.description ?: ''
            ]
        }
    }

    private static String csv(Map data, String bucket) {
        def rows = (data[bucket] ?: []) as List
        def keys = rows.collectMany { (it as Map).keySet() }.unique() - 'tags'
        def out = new StringBuilder()
        out.append(keys.join(',')).append('\n')
        rows.each { Map row ->
            out.append(keys.collect { cell(row[it]) }.join(',')).append('\n')
        }
        out.toString()
    }

    private static String cell(value) {
        def text = value?.toString() ?: ''
        '"' + text.replace('"', '""') + '"'
    }

    private static Map pdfCandidate(Map data, String id) {
        def row = row(data, 'candidates', id)
        if (!row) {
            return null
        }
        def lines = ['Candidat ' + OpenCatsModel.person(row), row.email1, row.phoneCell, row.city, row.keySkills, row.currentEmployer, row.notes]
        pdf(lines, 'candidat-' + id + '.pdf')
    }

    private static Map pdfJob(Map data, String id) {
        def row = row(data, 'jobs', id)
        if (!row) {
            return null
        }
        def lines = [
            'Poste ' + (row.title ?: ''),
            OpenCatsModel.caption(data, 'companies', row.companyId),
            row.city,
            row.type,
            row.status,
            row.description,
            row.notes
        ]
        pdf(lines, 'poste-' + id + '.pdf')
    }

    private static Map pdf(List lines, String filename) {
        ByteArrayOutputStream out = new ByteArrayOutputStream()
        Document document = new Document()
        PdfWriter.getInstance(document, out)
        document.open()
        lines.findAll { it }.each { document.add(new Paragraph(it.toString())) }
        document.add(new Paragraph('OpenCATS'))
        document.close()
        [bytes: out.toByteArray(), mime: 'application/pdf', filename: filename]
    }

    static Map row(Map data, String bucket, value) {
        if (!bucket || !value) {
            return null
        }
        ((data[bucket] ?: []) as List).find { it.id?.toString() == value.toString() }
    }

    private static String prefix(String form) {
        switch (form) {
            case 'candidate': return 'c'
            case 'company': return 'co'
            case 'contact': return 'ct'
            case 'job': return 'j'
            case 'event': return 'e'
            default: return 'x'
        }
    }

    private static boolean truth(value) {
        value == true || value?.toString() in ['1', 'on', 'true', 'yes']
    }

    private static String clip(String value, int max) {
        def text = value ?: ''
        text.length() > max ? text.substring(0, max) : text
    }

    private static List<String> splitCsv(String line) {
        def cells = []
        def current = new StringBuilder()
        boolean quoted = false
        line.each { ch ->
            if (ch == '"') {
                quoted = !quoted
            } else if (ch == ',' && !quoted) {
                cells << current.toString()
                current.setLength(0)
            } else {
                current.append(ch)
            }
        }
        cells << current.toString()
        cells
    }
}
