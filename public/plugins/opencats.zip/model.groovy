/**
 * OpenCATS vocabulary: pipeline, job orders, activities and the fields of each record.
 */
class OpenCatsModel {
    static final List<Map> PIPELINE = [
        [id: 'noContact', key: 'oc.p.noContact'],
        [id: 'contacted', key: 'oc.p.contacted'],
        [id: 'qualifying', key: 'oc.p.qualifying'],
        [id: 'submitted', key: 'oc.p.submitted'],
        [id: 'interviewing', key: 'oc.p.interviewing'],
        [id: 'offered', key: 'oc.p.offered'],
        [id: 'clientDeclined', key: 'oc.p.clientDeclined'],
        [id: 'candidateDeclined', key: 'oc.p.candidateDeclined'],
        [id: 'placed', key: 'oc.p.placed'],
        [id: 'aside', key: 'oc.p.aside']
    ]
    static final List<Map> JOB_TYPES = [
        [id: 'H', key: 'oc.t.hire'],
        [id: 'C', key: 'oc.t.contract'],
        [id: 'C2H', key: 'oc.t.contractHire'],
        [id: 'FL', key: 'oc.t.freelance']
    ]
    static final List<Map> JOB_STATUS = [
        [id: 'Active', key: 'oc.s.active'],
        [id: 'OnHold', key: 'oc.s.hold'],
        [id: 'Full', key: 'oc.s.full'],
        [id: 'Closed', key: 'oc.s.closed'],
        [id: 'Canceled', key: 'oc.s.canceled'],
        [id: 'Upcoming', key: 'oc.s.upcoming']
    ]
    static final List<Map> ACTIVITIES = [
        [id: 'callLeft', key: 'oc.a.callLeft'],
        [id: 'callTalked', key: 'oc.a.callTalked'],
        [id: 'email', key: 'oc.a.email'],
        [id: 'meeting', key: 'oc.a.meeting'],
        [id: 'note', key: 'oc.a.note'],
        [id: 'other', key: 'oc.a.other']
    ]
    static final List<Map> GENDERS = [
        [id: '', key: 'oc.u.unknown'],
        [id: 'F', key: 'oc.u.female'],
        [id: 'M', key: 'oc.u.male']
    ]
    static final List<Map> YESNO = [
        [id: '', key: 'oc.u.unknown'],
        [id: '1', key: 'oc.yes'],
        [id: '0', key: 'oc.no']
    ]
    static final List<Map> KINDS = [
        [id: 'candidates', key: 'oc.k.candidates'],
        [id: 'companies', key: 'oc.k.companies'],
        [id: 'contacts', key: 'oc.k.contacts'],
        [id: 'jobs', key: 'oc.k.jobs']
    ]
    static final List<String> WEEK = ['oc.d.mon', 'oc.d.tue', 'oc.d.wed', 'oc.d.thu', 'oc.d.fri', 'oc.d.sat', 'oc.d.sun']

    static Map text(String name, String key, boolean required = false) { [name: name, key: key, type: 'text', required: required, max: 240] }
    static Map email(String name, String key) { [name: name, key: key, type: 'email', max: 240] }
    static Map area(String name, String key) { [name: name, key: key, type: 'area', max: 8000] }
    static Map bool(String name, String key) { [name: name, key: key, type: 'bool'] }
    static Map date(String name, String key) { [name: name, key: key, type: 'date'] }
    static Map number(String name, String key) { [name: name, key: key, type: 'number'] }
    static Map choice(String name, String key, String options, boolean required = false) {
        [name: name, key: key, type: 'choice', options: options, required: required]
    }

    static List<Map> candidateFields() {
        [
            text('firstName', 'oc.f.first', true), text('middleName', 'oc.f.middle'), text('lastName', 'oc.f.last', true),
            email('email1', 'oc.f.email'), email('email2', 'oc.f.email2'),
            text('phoneHome', 'oc.f.phoneHome'), text('phoneCell', 'oc.f.phoneCell'), text('phoneWork', 'oc.f.phoneWork'),
            text('address', 'oc.f.address'), text('city', 'oc.f.city'), text('state', 'oc.f.state'), text('zip', 'oc.f.zip'),
            text('webSite', 'oc.f.web'), area('keySkills', 'oc.f.skills'), text('currentEmployer', 'oc.f.employer'),
            text('currentPay', 'oc.f.currentPay'), text('desiredPay', 'oc.f.desiredPay'), text('source', 'oc.f.source'),
            date('dateAvailable', 'oc.f.available'), bool('canRelocate', 'oc.f.relocate'), text('bestTimeToCall', 'oc.f.bestTime'),
            area('notes', 'oc.f.notes'), bool('isHot', 'oc.f.hot'), bool('isActive', 'oc.f.active'),
            choice('gender', 'oc.f.gender', 'gender'), choice('veteran', 'oc.f.veteran', 'yesno'),
            choice('disability', 'oc.f.disability', 'yesno'), text('ethnicity', 'oc.f.ethnicity')
        ]
    }

    static List<Map> companyFields() {
        [
            text('name', 'oc.f.name', true), text('address', 'oc.f.address'), text('city', 'oc.f.city'),
            text('state', 'oc.f.state'), text('zip', 'oc.f.zip'), text('phone1', 'oc.f.phone'), text('phone2', 'oc.f.phone2'),
            text('fax', 'oc.f.fax'), text('url', 'oc.f.url'), area('keyTechnologies', 'oc.f.technologies'),
            area('notes', 'oc.f.notes'), bool('isHot', 'oc.f.hot')
        ]
    }

    static List<Map> contactFields() {
        [
            choice('companyId', 'oc.f.company', 'companies'), text('firstName', 'oc.f.first'), text('lastName', 'oc.f.last', true),
            text('title', 'oc.f.jobTitle'), text('department', 'oc.f.department'), text('reportsTo', 'oc.f.reportsTo'),
            email('email1', 'oc.f.email'), email('email2', 'oc.f.email2'),
            text('phoneWork', 'oc.f.phoneWork'), text('phoneCell', 'oc.f.phoneCell'), text('phoneOther', 'oc.f.phoneOther'),
            text('address', 'oc.f.address'), text('city', 'oc.f.city'), text('state', 'oc.f.state'), text('zip', 'oc.f.zip'),
            area('notes', 'oc.f.notes'), bool('isHot', 'oc.f.hot')
        ]
    }

    static List<Map> jobFields() {
        [
            text('title', 'oc.f.jobTitle', true), choice('companyId', 'oc.f.company', 'companies'),
            choice('contactId', 'oc.f.contact', 'contacts'), choice('type', 'oc.f.type', 'jobType', true),
            choice('status', 'oc.f.status', 'jobStatus', true), text('city', 'oc.f.city'), text('state', 'oc.f.state'),
            text('duration', 'oc.f.duration'), text('maxRate', 'oc.f.rate'), text('salary', 'oc.f.salary'),
            number('openings', 'oc.f.openings'), number('openingsAvailable', 'oc.f.openingsLeft'),
            area('description', 'oc.f.description'), area('notes', 'oc.f.notes'), date('startDate', 'oc.f.start'),
            bool('isPublic', 'oc.f.public'), bool('isHot', 'oc.f.hot'), text('recruiter', 'oc.f.recruiter')
        ]
    }

    static List<Map> eventFields() {
        [
            text('title', 'oc.f.jobTitle', true), choice('type', 'oc.f.type', 'activity', true), date('date', 'oc.f.date'),
            text('time', 'oc.f.time'), number('duration', 'oc.f.durationMin'), bool('allDay', 'oc.f.allDay'),
            choice('kind', 'oc.f.regarding', 'kinds'), text('item', 'oc.f.regardingId'), area('notes', 'oc.f.notes')
        ]
    }

    static List<Map> fields(String form) {
        switch (form) {
            case 'candidate': return candidateFields()
            case 'company': return companyFields()
            case 'contact': return contactFields()
            case 'job': return jobFields()
            case 'event': return eventFields()
            default: return []
        }
    }

    static String bucket(String form) {
        switch (form) {
            case 'candidate': return 'candidates'
            case 'company': return 'companies'
            case 'contact': return 'contacts'
            case 'job': return 'jobs'
            case 'event': return 'events'
            case 'activity': return 'activities'
            case 'list': return 'lists'
            case 'template': return 'templates'
            case 'tag': return 'tags'
            default: return null
        }
    }

    static Map blank() {
        [
            seq        : 3,
            candidates : [],
            companies  : [],
            contacts   : [],
            jobs       : [],
            pipeline   : [],
            activities : [],
            events     : [],
            lists      : [],
            tags       : [],
            templates  : [
                [id: 'm1', title: 'Accuse de reception', body: 'Bonjour ${name},\n\nNous avons bien recu votre candidature pour ${job}.'],
                [id: 'm2', title: 'Convocation entretien', body: 'Bonjour ${name},\n\nUn entretien est propose pour ${job} le ${date}.']
            ],
            attachments: [],
            settings   : [siteName: 'OpenCATS', careers: '1', country: 'FR', city: '']
        ]
    }

    static String person(Map row) {
        [row?.firstName, row?.middleName, row?.lastName].findAll { it?.toString()?.trim() }.join(' ')
    }

    static String caption(Map data, String bucket, String id) {
        def row = ((data[bucket] ?: []) as List).find { it.id?.toString() == id?.toString() }
        if (!row) {
            return ''
        }
        switch (bucket) {
            case 'companies': return row.name ?: row.id
            case 'jobs': return row.title ?: row.id
            case 'templates': return row.title ?: row.id
            case 'lists': return row.name ?: row.id
            case 'tags': return row.name ?: row.id
            case 'events': return row.title ?: row.id
            default: return person(row) ?: row.name ?: row.title ?: row.id
        }
    }

    static String named(List<Map> options, String id, Closure text) {
        def found = options.find { it.id?.toString() == (id ?: '').toString() }
        found ? text(found.key) : (id ?: '')
    }

    static int rank(Map row) {
        def digits = (row?.id ?: '').toString().replaceAll('\\D', '')
        digits ? Integer.parseInt(digits) : 0
    }
}
