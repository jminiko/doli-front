import backend.dsl.FeatureModule
import backend.dsl.PluginApi
import backend.dsl.Workbench

/**
 * OpenCATS applicant tracking, installed from the modules screen.
 * Records stay on this server. Email templates are logged as activities and are not sent out.
 */
class OpenCatsModule extends FeatureModule implements PluginApi {
    String code = 'opencats'
    String family = 'hr'
    String titleKey = 'oc.title'
    String icon = 'bi-person-badge'
    String mainMenu = 'opencats'
    int position = 86
    String version = '1.0.0'
    boolean external = true

    private final Object gate = new Object()

    void contribute(Workbench workbench) {
        workbench.page(code) {
            titleKey = 'oc.title'
            icon = 'bi-person-badge'
            systemPage = 'plugin'
            menu = 'opencats'
            menuHidden = true
        }
        menus().each { Map group ->
            workbench.block(menu: mainMenu, id: group.id, title: group.title, icon: group.icon, order: group.order as int) {
                group.entries.each { Map item ->
                    node(item.id) {
                        titleKey = item.title
                        targetScreen = 'opencats'
                        mode = 'system'
                        systemPage = 'plugin'
                        level = item.level as int
                        order = item.order as int
                        query = item.query
                        icon = 'bi-list-ul'
                    }
                }
            }
        }
    }

    Map<String, Map<String, String>> labels() {
        Map<String, Map<String, String>> out = [fr: [:], en: [:], de: [:], es: [:]]
        OpenCatsLabels.rows().each { List<String> row ->
            ['fr', 'en', 'de', 'es'].eachWithIndex { String locale, int index -> out[locale][row[0]] = row[index + 1] }
        }
        out
    }

    Map panel(Locale locale, Closure text) { open([section: 'dashboard'], locale, text) }

    Map dispatch(String verb, Long id, Locale locale, Closure text) {
        act(verb, [row: id], locale, text)
    }

    Map open(Map query, Locale locale, Closure text) {
        synchronized (gate) {
            def data = OpenCatsStore.load()
            def notice = data.notice
            if (notice) {
                data.notice = null
                OpenCatsStore.write(data)
            }
            def page = OpenCatsDesk.page(data, query ?: [:], text)
            if (notice) {
                page.notice = text(notice.toString())
            }
            page
        }
    }

    Map act(String verb, Map payload, Locale locale, Closure text) {
        synchronized (gate) {
            def data = OpenCatsStore.load()
            def body = payload ?: [:]
            OpenCatsActions.run(data, verb, body)
            OpenCatsStore.write(data)
            [notice: text(data.notice?.toString() ?: 'oc.saved'), section: body.section ?: 'dashboard', row: body.row ?: '']
        }
    }

    Map blob(String nodeId) {
        synchronized (gate) {
            OpenCatsActions.document(OpenCatsStore.load(), nodeId)
        }
    }

    Map careers(Locale locale, Closure text) {
        synchronized (gate) {
            def page = OpenCatsActions.careers(OpenCatsStore.load(), text)
            page.labels = [
                first: text('oc.f.first'), last: text('oc.f.last'), email: text('oc.f.email'),
                phone: text('oc.f.phoneCell'), city: text('oc.f.city'), notes: text('oc.f.notes'),
                apply: text('oc.apply'), sent: text('oc.applied')
            ]
            page
        }
    }

    Map applyCareer(Map payload, Locale locale, Closure text) {
        synchronized (gate) {
            def data = OpenCatsStore.load()
            OpenCatsActions.applyCareer(data, payload ?: [:])
            OpenCatsStore.write(data)
            [ok: true, notice: text('oc.applied')]
        }
    }

    void retire() {
        def dir = OpenCatsStore.root()
        if (dir.exists()) {
            dir.deleteDir()
        }
    }

    private static List<Map> menus() {
        [
            [id: 'oc-recruit', title: 'oc.recruit', icon: 'bi-people', order: 10, entries: [
                [id: 'oc-home', title: 'oc.home', level: 1, order: 10, query: 'section=dashboard'],
                [id: 'oc-candidates', title: 'oc.candidates', level: 1, order: 20, query: 'section=candidates'],
                [id: 'oc-candidate-new', title: 'oc.candidateNew', level: 2, order: 21, query: 'section=candidates&row=new'],
                [id: 'oc-companies', title: 'oc.companies', level: 1, order: 30, query: 'section=companies'],
                [id: 'oc-company-new', title: 'oc.companyNew', level: 2, order: 31, query: 'section=companies&row=new'],
                [id: 'oc-contacts', title: 'oc.contacts', level: 1, order: 40, query: 'section=contacts'],
                [id: 'oc-contact-new', title: 'oc.contactNew', level: 2, order: 41, query: 'section=contacts&row=new'],
                [id: 'oc-jobs', title: 'oc.jobs', level: 1, order: 50, query: 'section=jobs'],
                [id: 'oc-job-new', title: 'oc.jobNew', level: 2, order: 51, query: 'section=jobs&row=new']
            ]],
            [id: 'oc-follow', title: 'oc.follow', icon: 'bi-calendar-event', order: 20, entries: [
                [id: 'oc-calendar', title: 'oc.calendar', level: 1, order: 10, query: 'section=calendar'],
                [id: 'oc-activities', title: 'oc.activities', level: 1, order: 20, query: 'section=activities'],
                [id: 'oc-lists', title: 'oc.lists', level: 1, order: 30, query: 'section=lists'],
                [id: 'oc-list-new', title: 'oc.listNew', level: 2, order: 31, query: 'section=lists&row=new']
            ]],
            [id: 'oc-admin', title: 'oc.admin', icon: 'bi-gear', order: 30, entries: [
                [id: 'oc-reports', title: 'oc.reports', level: 1, order: 10, query: 'section=reports'],
                [id: 'oc-templates', title: 'oc.templates', level: 1, order: 20, query: 'section=templates'],
                [id: 'oc-import', title: 'oc.import', level: 1, order: 30, query: 'section=import'],
                [id: 'oc-tags', title: 'oc.tags', level: 1, order: 40, query: 'section=tags'],
                [id: 'oc-settings', title: 'oc.settings', level: 1, order: 50, query: 'section=settings'],
                [id: 'oc-portal', title: 'oc.portal', level: 1, order: 60, query: 'section=portal']
            ]]
        ]
    }
}
