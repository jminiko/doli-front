import java.time.LocalDate
import java.time.YearMonth

/** Builds the OpenCATS pages consumed by both desks. */
class OpenCatsDesk {
    static Map page(Map data, Map query, Closure text) {
        String section = query?.section?.toString() ?: 'dashboard'
        if (!(section in ['dashboard', 'candidates', 'companies', 'contacts', 'jobs', 'calendar', 'activities', 'lists', 'reports', 'templates', 'import', 'tags', 'settings', 'portal'])) {
            section = 'dashboard'
        }
        def page = [
            kind   : 'ats',
            code   : 'opencats',
            section: section,
            heading: text(titleKey(section)),
            tabs   : tabs(section, text),
            labels : labels(text),
            empty  : text('oc.empty'),
            notes  : []
        ]
        switch (section) {
            case 'dashboard': dashboard(page, data, text); break
            case 'candidates': people(page, data, query, text, 'candidate'); break
            case 'companies': people(page, data, query, text, 'company'); break
            case 'contacts': people(page, data, query, text, 'contact'); break
            case 'jobs': people(page, data, query, text, 'job'); break
            case 'calendar': calendar(page, data, query, text); break
            case 'activities': activityList(page, data, text); break
            case 'lists': lists(page, data, query, text); break
            case 'reports': reports(page, data, text); break
            case 'templates': templates(page, data, query, text); break
            case 'import': importer(page, text); break
            case 'tags': tagAdmin(page, data, query, text); break
            case 'settings': settings(page, data, text); break
            case 'portal': portal(page, data, text); break
        }
        page
    }

    private static void dashboard(Map page, Map data, Closure text) {
        def today = LocalDate.now().toString()
        page.notes = [text('oc.hint.home')]
        page.stats = [
            [label: text('oc.candidates'), value: (data.candidates ?: []).size()],
            [label: text('oc.companies'), value: (data.companies ?: []).size()],
            [label: text('oc.contacts'), value: (data.contacts ?: []).size()],
            [label: text('oc.jobs'), value: (data.jobs ?: []).findAll { it.status == 'Active' }.size()],
            [label: text('oc.h.pipeline'), value: (data.pipeline ?: []).findAll { !(it.status in ['placed', 'clientDeclined', 'candidateDeclined', 'aside']) }.size()],
            [label: text('oc.h.placements'), value: (data.pipeline ?: []).findAll { it.status == 'placed' }.size()]
        ]
        page.related = [
            table(text('oc.h.recent'), [text('oc.col.date'), text('oc.col.type'), text('oc.col.regarding'), text('oc.col.detail')], recentActivities(data, text).take(8).collect { it }),
            table(text('oc.h.hotList'), [text('oc.col.name'), text('oc.col.city'), text('oc.col.skills')], (data.candidates ?: []).findAll { it.isHot == '1' && it.isActive != '0' }.toSorted { -OpenCatsModel.rank(it) }.take(8).collect { [section: 'candidates', row: it.id, cells: [OpenCatsModel.person(it), it.city, it.keySkills]] }),
            table(text('oc.h.upcoming'), [text('oc.col.date'), text('oc.col.title'), text('oc.col.detail')], (data.events ?: []).findAll { (it.date ?: '') >= today }.toSorted { it.date }.take(8).collect { [section: 'calendar', row: it.id, cells: [it.date, it.title, it.time]] })
        ]
        page.links = [
            [section: 'candidates', row: 'new', label: text('oc.candidateNew')],
            [section: 'jobs', row: 'new', label: text('oc.jobNew')]
        ]
    }

    private static void people(Map page, Map data, Map query, Closure text, String form) {
        String bucket = OpenCatsModel.bucket(form)
        def current = query.row?.toString()
        if (current) {
            card(page, data, query, text, form, current == 'new' ? [:] : OpenCatsActions.row(data, bucket, current))
            return
        }
        String q = query.q?.toString()?.trim() ?: ''
        String hot = query.hot?.toString() ?: ''
        String active = query.active?.toString()
        if (active == null && form == 'candidate') {
            active = '1'
        }
        String status = query.status?.toString() ?: ''
        page.filters = filters(text, form, q, hot, active, status)
        page.links = [[section: page.section, row: 'new', label: text(createKey(form))]]
        page.export = [label: text('oc.csv'), node: "csv-${bucket}"]
        def rows = ((data[bucket] ?: []) as List).findAll { Map row ->
            if (hot == '1' && row.isHot != '1') return false
            if (form == 'candidate' && active == '1' && row.isActive == '0') return false
            if (form == 'candidate' && active == '0' && row.isActive != '0') return false
            if (status && row.status != status) return false
            !q || searchable(row, data).toLowerCase().contains(q.toLowerCase())
        }.toSorted { -OpenCatsModel.rank(it) }
        page.table = [
            headers: headers(form, text),
            rows   : rows.collect { Map row ->
                [section: page.section, row: row.id, mark: row.isHot == '1', cells: cells(data, form, row, text)]
            }
        ]
    }

    private static void card(Map page, Map data, Map query, Closure text, String form, Map record) {
        if (query.row?.toString() != 'new' && !record) {
            page.notes = [text('oc.empty')]
            return
        }
        def fresh = new LinkedHashMap(defaults(form))
        (record ?: [:]).each { key, value ->
            if (value != null && value != '') {
                fresh[key] = value
            }
        }
        page.row = fresh.id ?: ''
        page.heading = fresh.id ? caption(data, form, fresh) : text(createKey(form))
        page.form = [
            form  : form,
            row   : fresh.id ?: '',
            fields: showFields(data, text, OpenCatsModel.fields(form), fresh),
            confirm: form == 'candidate'
        ]
        page.export = fresh.id && form in ['candidate', 'job'] ? [label: text('oc.pdf'), node: "pdf-${form}-${fresh.id}"] : null
        if (form == 'candidate' && fresh.id) {
            page.pipeline = pipeline(data, text, 'candidate', fresh.id)
        }
        if (form == 'job' && fresh.id) {
            page.pipeline = pipeline(data, text, 'job', fresh.id)
        }
        if (fresh.id) {
            String kind = OpenCatsModel.bucket(form)
            page.activity = activityBox(data, text, kind, fresh.id)
            page.files = fileBox(data, text, kind, fresh.id)
            page.tagBox = tagBox(data, text, kind, fresh.id)
            page.listAdd = listChoices(data, text, kind)
        }
        if (form == 'company' && fresh.id) {
            page.related = [
                table(text('oc.contacts'), [text('oc.col.name'), text('oc.col.title'), text('oc.col.email')], (data.contacts ?: []).findAll { it.companyId == fresh.id }.collect { [section: 'contacts', row: it.id, cells: [OpenCatsModel.person(it), it.title, it.email1]] }),
                table(text('oc.jobs'), [text('oc.col.title'), text('oc.col.status'), text('oc.col.city')], (data.jobs ?: []).findAll { it.companyId == fresh.id }.collect { [section: 'jobs', row: it.id, cells: [it.title, OpenCatsModel.named(OpenCatsModel.JOB_STATUS, it.status, text), it.city]] })
            ]
        }
    }

    private static void calendar(Map page, Map data, Map query, Closure text) {
        def month = month(query.month?.toString())
        def record = query.row ? OpenCatsActions.row(data, 'events', query.row) : [:]
        if (!record && query.date ==~ /\d{4}-\d{2}-\d{2}/) {
            record = [date: query.date.toString()]
        }
        page.calendar = grid(data, month, text)
        page.form = [
            form  : 'event',
            row   : record?.id ?: '',
            fields: showFields(data, text, OpenCatsModel.eventFields(), record ?: [:])
        ]
    }

    private static void activityList(Map page, Map data, Closure text) {
        page.table = [
            headers: [text('oc.col.date'), text('oc.col.type'), text('oc.col.regarding'), text('oc.col.detail')],
            rows   : recentActivities(data, text)
        ]
    }

    private static void lists(Map page, Map data, Map query, Closure text) {
        def current = query.row?.toString()
        if (current && current != 'new') {
            def list = OpenCatsActions.row(data, 'lists', current)
            if (!list) {
                page.notes = [text('oc.empty')]
                return
            }
            page.row = list.id
            page.heading = list.name
            page.form = listForm(text, list)
            def bucket = list.kind?.toString()
            page.related = [
                table(text('oc.h.members'), [text('oc.col.name')], (list.items ?: []).collect { id ->
                    [section: sectionOf(bucket), row: id, cells: [OpenCatsModel.caption(data, bucket, id.toString())]]
                })
            ]
            return
        }
        page.links = [[section: 'lists', row: 'new', label: text('oc.listNew')]]
        if (current == 'new') {
            page.form = listForm(text, [:])
        }
        page.table = [
            headers: [text('oc.col.name'), text('oc.col.kind'), text('oc.col.count')],
            rows   : (data.lists ?: []).collect { list ->
                [section: 'lists', row: list.id, cells: [list.name, text(kindKey(list.kind)), (list.items ?: []).size().toString()]]
            }
        ]
    }

    private static void templates(Map page, Map data, Map query, Closure text) {
        def current = query.row?.toString()
        page.notes = [text('oc.hint.mail')]
        page.links = [[section: 'templates', row: 'new', label: text('oc.templateNew')]]
        if (current) {
            def row = current == 'new' ? [:] : OpenCatsActions.row(data, 'templates', current)
            if (current != 'new' && !row) {
                page.notes << text('oc.empty')
            } else {
                page.form = [
                    form  : 'template',
                    row   : row?.id ?: '',
                    fields: [
                        [name: 'title', label: text('oc.col.title'), type: 'text', value: row?.title ?: '', required: true],
                        [name: 'body', label: text('oc.f.body'), type: 'area', value: row?.body ?: '', required: true]
                    ]
                ]
            }
        }
        page.table = [
            headers: [text('oc.col.title')],
            rows   : (data.templates ?: []).collect { [section: 'templates', row: it.id, cells: [it.title]] }
        ]
    }

    private static void importer(Map page, Closure text) {
        page.notes = [text('oc.hint.import')]
        page.form = [
            form  : 'import',
            row   : '',
            fields: [[name: 'csv', label: text('oc.f.csv'), type: 'area', value: 'firstName,lastName,email1,phoneCell,city,keySkills,source,currentEmployer\n', required: true]]
        ]
    }

    private static void tagAdmin(Map page, Map data, Map query, Closure text) {
        def current = query.row?.toString()
        page.links = [[section: 'tags', row: 'new', label: text('oc.tagNew')]]
        if (current) {
            def row = current == 'new' ? [:] : OpenCatsActions.row(data, 'tags', current)
            if (row != null) {
                page.form = [
                    form  : 'tag',
                    row   : row?.id ?: '',
                    fields: [[name: 'name', label: text('oc.f.tagName'), type: 'text', value: row?.name ?: '', required: true]]
                ]
            }
        }
        page.table = [
            headers: [text('oc.col.name'), text('oc.col.count')],
            rows   : (data.tags ?: []).collect { tag ->
                int count = 0
                ['candidates', 'companies', 'contacts', 'jobs'].each { bucket ->
                    count += (data[bucket] ?: []).count { (it.tags ?: []).contains(tag.id) }
                }
                [section: 'tags', row: tag.id, cells: [tag.name, count.toString()]]
            }
        ]
    }

    private static void settings(Map page, Map data, Closure text) {
        def settings = data.settings ?: [:]
        page.form = [
            form  : 'settings',
            row   : '',
            fields: [
                [name: 'siteName', label: text('oc.f.siteName'), type: 'text', value: settings.siteName ?: 'OpenCATS', required: true],
                [name: 'careers', label: text('oc.f.careers'), type: 'bool', value: settings.careers == '1' ? '1' : '0'],
                [name: 'city', label: text('oc.f.city'), type: 'text', value: settings.city ?: ''],
                [name: 'country', label: text('oc.f.country'), type: 'text', value: settings.country ?: '']
            ]
        ]
    }

    private static void portal(Map page, Map data, Closure text) {
        page.notes = [text('oc.hint.portal'), '/careers']
        def jobs = (data.jobs ?: []).findAll { it.isPublic == '1' && it.status == 'Active' }
        page.table = [
            headers: [text('oc.col.title'), text('oc.col.company'), text('oc.col.city')],
            rows   : jobs.collect { [section: 'jobs', row: it.id, cells: [it.title, OpenCatsModel.caption(data, 'companies', it.companyId), it.city]] }
        ]
    }

    private static Map pipeline(Map data, Closure text, String side, String id) {
        def rows = (data.pipeline ?: []).findAll { side == 'candidate' ? it.candidate == id : it.job == id }
        def used = rows.collect { side == 'candidate' ? it.job : it.candidate } as Set
        def choices = (side == 'candidate' ? data.jobs : data.candidates).findAll { !(it.id in used) }.collect {
            [value: it.id, label: side == 'candidate' ? it.title : OpenCatsModel.person(it)]
        }
        [
            title   : text('oc.h.pipeline'),
            side    : side,
            anchor  : id,
            statuses: OpenCatsModel.PIPELINE.collect { [value: it.id, label: text(it.key)] },
            choices : choices,
            rows    : rows.collect { link ->
                def other = side == 'candidate' ? link.job : link.candidate
                def bucket = side == 'candidate' ? 'jobs' : 'candidates'
                [
                    candidate: link.candidate,
                    job      : link.job,
                    status   : link.status,
                    rating   : link.rating ?: '0',
                    section  : sectionOf(bucket),
                    row      : other,
                    label    : OpenCatsModel.caption(data, bucket, other)
                ]
            }
        ]
    }

    private static Map activityBox(Map data, Closure text, String kind, String item) {
        [
            title    : text('oc.h.activity'),
            hint     : text('oc.hint.mail'),
            kind     : kind,
            item     : item,
            types    : OpenCatsModel.ACTIVITIES.collect { [value: it.id, label: text(it.key)] },
            templates: [[value: '', label: text('oc.none')]] + (data.templates ?: []).collect { [value: it.id, label: it.title] },
            rows     : (data.activities ?: []).findAll { it.kind == kind && it.item == item }.toSorted { it.date }.reverse().collect {
                [date: it.date, type: OpenCatsModel.named(OpenCatsModel.ACTIVITIES, it.type, text), owner: it.owner, notes: it.notes]
            }
        ]
    }

    private static Map fileBox(Map data, Closure text, String kind, String item) {
        [
            title: text('oc.h.files'),
            kind : kind,
            item : item,
            rows : (data.attachments ?: []).findAll { it.kind == kind && it.item == item }.collect { [node: "file-${it.id}", name: it.name] }
        ]
    }

    private static Map tagBox(Map data, Closure text, String kind, String item) {
        def record = OpenCatsActions.row(data, kind, item)
        def selected = (record?.tags ?: []) as Set
        [
            title: text('oc.h.tags'),
            kind : kind,
            item : item,
            items: (data.tags ?: []).collect { [id: it.id, name: it.name, on: it.id in selected] }
        ]
    }

    private static Map listChoices(Map data, Closure text, String kind) {
        [
            label  : text('oc.lists'),
            kind   : kind,
            choices: (data.lists ?: []).findAll { it.kind == kind }.collect { [value: it.id, label: it.name] }
        ]
    }

    private static List<Map> recentActivities(Map data, Closure text) {
        ((data.activities ?: []) as List).toSorted { a, b -> (b.date ?: '') <=> (a.date ?: '') ?: OpenCatsModel.rank(b) <=> OpenCatsModel.rank(a) }.collect {
            [
                section: sectionOf(it.kind),
                row    : it.item,
                cells  : [it.date, OpenCatsModel.named(OpenCatsModel.ACTIVITIES, it.type, text), OpenCatsModel.caption(data, it.kind?.toString(), it.item?.toString()), it.notes]
            ]
        }
    }

    private static Map grid(Map data, YearMonth month, Closure text) {
        def cursor = month.atDay(1).minusDays(month.atDay(1).dayOfWeek.value - 1)
        def weeks = []
        6.times {
            def week = []
            7.times {
                def date = cursor.toString()
                week << [
                    date   : date,
                    inMonth: cursor.month == month.month,
                    events : (data.events ?: []).findAll { it.date == date }.collect { [id: it.id, title: it.title, time: it.allDay == '1' ? '' : it.time] }
                ]
                cursor = cursor.plusDays(1)
            }
            weeks << week
        }
        [
            month   : month.toString(),
            prev    : month.minusMonths(1).toString(),
            next    : month.plusMonths(1).toString(),
            weekdays: OpenCatsModel.WEEK.collect { text(it) },
            weeks   : weeks
        ]
    }

    private static void reports(Map page, Map data, Closure text) {
        page.reports = [
            countReport(text('oc.h.bySource'), text('oc.col.source'), (data.candidates ?: []).groupBy { it.source ?: text('oc.none') }),
            countReport(text('oc.h.byStatus'), text('oc.col.status'), (data.jobs ?: []).groupBy { OpenCatsModel.named(OpenCatsModel.JOB_STATUS, it.status, text) }),
            countReport(text('oc.h.byPipeline'), text('oc.col.status'), (data.pipeline ?: []).groupBy { OpenCatsModel.named(OpenCatsModel.PIPELINE, it.status, text) }),
            countReport(text('oc.h.byActivity'), text('oc.col.type'), (data.activities ?: []).groupBy { OpenCatsModel.named(OpenCatsModel.ACTIVITIES, it.type, text) }),
            [
                title  : text('oc.h.placements'),
                headers: [text('oc.candidates'), text('oc.jobs'), text('oc.companies'), text('oc.col.date')],
                rows   : (data.pipeline ?: []).findAll { it.status == 'placed' }.collect { link ->
                    def job = OpenCatsActions.row(data, 'jobs', link.job)
                    [OpenCatsModel.caption(data, 'candidates', link.candidate), job?.title, OpenCatsModel.caption(data, 'companies', job?.companyId), link.updated]
                }
            ]
        ]
    }

    private static Map countReport(String title, String header, Map grouped) {
        [
            title  : title,
            headers: [header, 'N'],
            rows   : grouped.collect { key, values -> [key?.toString() ?: '', values.size().toString()] }.toSorted { it[0] }
        ]
    }

    private static List<Map> filters(Closure text, String form, String q, String hot, String active, String status) {
        def list = [
            [name: 'q', label: text('oc.search'), value: q],
            [name: 'hot', label: text('oc.hot'), value: hot, options: [[value: '', label: text('oc.all')], [value: '1', label: text('oc.yes')]]]
        ]
        if (form == 'candidate') {
            list << [name: 'active', label: text('oc.f.active'), value: active ?: '', options: [[value: '1', label: text('oc.activeOnly')], [value: '0', label: text('oc.inactive')], [value: 'all', label: text('oc.all')]]]
        }
        if (form == 'job') {
            list << [name: 'status', label: text('oc.f.status'), value: status, options: [[value: '', label: text('oc.all')]] + OpenCatsModel.JOB_STATUS.collect { [value: it.id, label: text(it.key)] }]
        }
        list
    }

    private static List<Map> showFields(Map data, Closure text, List<Map> fields, Map record) {
        fields.collect { Map field ->
            def shown = [
                name    : field.name,
                label   : text(field.key),
                type    : field.type,
                value   : record[field.name] ?: (field.name == 'isActive' && !record.id ? '1' : ''),
                required: field.required == true
            ]
            def options = fieldOptions(data, text, field.options)
            if (options != null) {
                shown.options = options
            }
            shown
        }
    }

    private static List<Map> fieldOptions(Map data, Closure text, String name) {
        if (!name) {
            return null
        }
        List<Map> fixed = []
        switch (name) {
            case 'jobType': fixed = OpenCatsModel.JOB_TYPES; break
            case 'jobStatus': fixed = OpenCatsModel.JOB_STATUS; break
            case 'activity': fixed = OpenCatsModel.ACTIVITIES; break
            case 'gender': fixed = OpenCatsModel.GENDERS; break
            case 'yesno': fixed = OpenCatsModel.YESNO; break
            case 'kinds': fixed = OpenCatsModel.KINDS; break
            case 'companies':
                return [[value: '', label: text('oc.none')]] + (data.companies ?: []).collect { [value: it.id, label: it.name] }
            case 'contacts':
                return [[value: '', label: text('oc.none')]] + (data.contacts ?: []).collect { [value: it.id, label: OpenCatsModel.person(it)] }
            default: return null
        }
        fixed.collect { [value: it.id, label: text(it.key)] }
    }

    private static Map listForm(Closure text, Map list) {
        [
            form  : 'list',
            row   : list?.id ?: '',
            fields: [
                [name: 'name', label: text('oc.f.listName'), type: 'text', value: list?.name ?: '', required: true],
                [name: 'kind', label: text('oc.f.listKind'), type: 'choice', value: list?.kind ?: 'candidates', required: true, options: OpenCatsModel.KINDS.collect { [value: it.id, label: text(it.key)] }]
            ]
        ]
    }

    private static Map table(String title, List headers, List rows) {
        [title: title, headers: headers, rows: rows]
    }

    private static List<String> headers(String form, Closure text) {
        switch (form) {
            case 'candidate': return [text('oc.col.name'), text('oc.col.city'), text('oc.col.email'), text('oc.col.skills'), text('oc.col.source')]
            case 'company': return [text('oc.col.name'), text('oc.col.city'), text('oc.col.phone')]
            case 'contact': return [text('oc.col.name'), text('oc.col.company'), text('oc.col.title'), text('oc.col.email'), text('oc.col.phone')]
            default: return [text('oc.col.title'), text('oc.col.company'), text('oc.col.type'), text('oc.col.status'), text('oc.col.city'), text('oc.col.openings')]
        }
    }

    private static List cells(Map data, String form, Map row, Closure text) {
        switch (form) {
            case 'candidate': return [OpenCatsModel.person(row), row.city, row.email1, row.keySkills, row.source]
            case 'company': return [row.name, row.city, row.phone1]
            case 'contact': return [OpenCatsModel.person(row), OpenCatsModel.caption(data, 'companies', row.companyId), row.title, row.email1, row.phoneWork]
            default: return [row.title, OpenCatsModel.caption(data, 'companies', row.companyId), OpenCatsModel.named(OpenCatsModel.JOB_TYPES, row.type, text), OpenCatsModel.named(OpenCatsModel.JOB_STATUS, row.status, text), row.city, row.openings]
        }
    }

    private static String caption(Map data, String form, Map row) {
        switch (form) {
            case 'company': return row.name ?: ''
            case 'job': return row.title ?: ''
            default: return OpenCatsModel.person(row)
        }
    }

    private static Map defaults(String form) {
        form == 'job' ? [type: 'H', status: 'Active'] : (form == 'candidate' ? [isActive: '1'] : [:])
    }

    private static String searchable(Map row, Map data) {
        [row.values(), OpenCatsModel.caption(data, 'companies', row.companyId?.toString())].flatten().findAll { !(it instanceof Map) && !(it instanceof List) }.join(' ')
    }

    private static List<Map> tabs(String current, Closure text) {
        ['dashboard', 'candidates', 'companies', 'contacts', 'jobs', 'calendar', 'activities', 'lists', 'reports'].collect {
            [section: it, label: text(titleKey(it)), current: it == current]
        }
    }

    private static Map labels(Closure text) {
        [
            save: text('oc.save'), remove: text('oc.remove'), search: text('oc.search'), add: text('oc.add'),
            pdf: text('oc.pdf'), csv: text('oc.csv'), empty: text('oc.empty'), all: text('oc.all'),
            yes: text('oc.yes'), no: text('oc.no'), none: text('oc.none'), force: text('oc.f.force')
        ]
    }

    private static String titleKey(String section) {
        switch (section) {
            case 'candidates': return 'oc.candidates'
            case 'companies': return 'oc.companies'
            case 'contacts': return 'oc.contacts'
            case 'jobs': return 'oc.jobs'
            case 'calendar': return 'oc.calendar'
            case 'activities': return 'oc.activities'
            case 'lists': return 'oc.lists'
            case 'reports': return 'oc.reports'
            case 'templates': return 'oc.templates'
            case 'import': return 'oc.import'
            case 'tags': return 'oc.tags'
            case 'settings': return 'oc.settings'
            case 'portal': return 'oc.portal'
            default: return 'oc.home'
        }
    }

    private static String createKey(String form) {
        switch (form) {
            case 'company': return 'oc.companyNew'
            case 'contact': return 'oc.contactNew'
            case 'job': return 'oc.jobNew'
            default: return 'oc.candidateNew'
        }
    }

    private static String kindKey(String kind) {
        switch (kind) {
            case 'companies': return 'oc.k.companies'
            case 'contacts': return 'oc.k.contacts'
            case 'jobs': return 'oc.k.jobs'
            default: return 'oc.k.candidates'
        }
    }

    private static String sectionOf(String bucket) {
        switch (bucket) {
            case 'companies': return 'companies'
            case 'contacts': return 'contacts'
            case 'jobs': return 'jobs'
            case 'events': return 'calendar'
            default: return 'candidates'
        }
    }

    private static YearMonth month(String raw) {
        try {
            return raw ==~ /\d{4}-\d{2}/ ? YearMonth.parse(raw) : YearMonth.now()
        } catch (ignored) {
            return YearMonth.now()
        }
    }
}
